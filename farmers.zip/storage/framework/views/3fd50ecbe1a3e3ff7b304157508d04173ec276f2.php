<?php $__env->startSection("content"); ?>
    <div class="wrapper">
        <div class="page">
            <div class="sidebar-backdrop"></div>
            <!-- .page-cover -->
            <?php echo $__env->make("farmers._page_cover", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- .page-navs -->
            <?php echo $__env->make("farmers._page_nav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="page-inner">
                <!-- .page-title-bar -->
                <header class="page-title-bar">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active">
                                <a href="<?php echo e(route("farmers.show", $farmer)); ?>">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i>
                                    <?php echo e($farmer->full_name); ?>

                                </a>
                            </li>
                        </ol>
                    </nav>
                    <div class="d-sm-flex align-items-sm-center">
                        <h1 class="page-title mr-sm-auto">
                            Blocks
                            <small class="badge"><?php echo e($farmer->householdBlocks->count()); ?> Totals</small>
                        </h1>
                        <div class="btn-toolbar">
                            <button type="button" class="btn btn-light">
                                <i class="oi oi-data-transfer-download"></i>
                                <span class="ml-1">Export</span>
                            </button>
                            <button type="button" class="btn btn-light">
                                <i class="oi oi-data-transfer-upload"></i>
                                <span class="ml-1">Import</span>
                            </button>
                            <a href="<?php echo e(route("farmers.blocks.create", $farmer)); ?>" class="btn btn-primary">
                                <span class="fas fa-plus mr-1"></span>
                                Add a new block
                            </a>
                        </div>
                    </div>
                </header>

                <!-- .page-section -->
                <div class="page-section">

                    <?php if($farmer->householdBlocks->count()): ?>
                        <section class="card card-fluid">
                            <header class="card-header">
                                <ul class="nav nav-tabs card-header-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(request()->query("status") ? "" : "active"); ?>"
                                           href="<?php echo e(route("purchases.index")); ?>"
                                        >
                                            All
                                        </a>
                                    </li>
                                </ul>
                            </header>

                            <div class="card-body">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <span class="oi oi-magnifying-glass"></span>
                                        </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Search record">
                                    </div>
                                </div>

                                <!-- .table-responsive -->
                                <div class="text-muted"> Showing 1 to 10 of 1,000 entries </div>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th class="text-left" nowrap>Number</th>
                                            <th class="text-right" nowrap>Size</th>
                                            <th class="text-left" nowrap>Farm</th>
                                            <th class="text-left" nowrap>Product</th>
                                            <th class="text-left" nowrap>Status</th>
                                            <th class="text-right" nowrap></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $farmer->householdBlocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-left align-middle" nowrap>
                                                    <?php echo e($block->number); ?>

                                                </td>
                                                <td class="text-right align-middle" nowrap>
                                                    <?php echo e($block->size); ?> <?php echo e($block->size_unit); ?>

                                                </td>
                                                <td class="text-left align-middle" nowrap>
                                                    <?php echo e($block->farm->name); ?>

                                                </td>
                                                <td class="text-left align-middle" nowrap>
                                                    <?php echo e($block->product->name); ?>

                                                </td>
                                                <td class="text-left text-capitalize align-middle" nowrap>
                                                    <?php echo e($block->status); ?>

                                                </td>
                                                <td></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- .pagination -->
                                
                            </div>
                        </section>
                    <?php else: ?>
                        <div class="alert alert-info has-icon alert-dismissible fade show">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <div class="alert-icon">
                                <span class="oi oi-flag"></span>
                            </div>
                            <h4 class="alert-heading"> Warning! </h4>
                            <p class="mb-0">
                                Best check yo self, you're not looking too good. Nulla vitae elit libero, a pharetra
                                augue. Praesent commodo cursus magna,
                                <a href="#" class="alert-link">vel scelerisque nisl consectetur et</a>.
                            </p>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>