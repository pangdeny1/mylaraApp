<?php

use Faker\Generator as Faker;

$factory->define(App\HouseholdBlock::class, function (Faker $faker) {
    return [
        //
    ];
});
