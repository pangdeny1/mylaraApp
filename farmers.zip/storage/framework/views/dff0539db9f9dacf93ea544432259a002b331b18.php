<?php $__env->startSection("content"); ?>
    <?php if($clusters->count()): ?>
        <div class="wrapper">
            <div class="page">
                <div class="page-inner">
                    <header class="page-title-bar">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">
                                    <a href="#">
                                        <i class="breadcrumb-icon fa fa-angle-left mr-2"></i>Clusters</a>
                                </li>
                            </ol>
                        </nav>

                        <div class="d-sm-flex align-items-sm-center">
                            <h1 class="page-title mr-sm-auto mb-0"> Clusters </h1>
                            <div class="btn-toolbar">
                                <button type="button" class="btn btn-light">
                                    <i class="oi oi-data-transfer-download"></i>
                                    <span class="ml-1">Export</span>
                                </button>
                                <button type="button" class="btn btn-light">
                                    <i class="oi oi-data-transfer-upload"></i>
                                    <span class="ml-1">Import</span>
                                </button>
                            </div>
                        </div>
                    </header>
                    <div class="page-section">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissible fade show has-icon">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <div class="alert-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                                <strong>Well done!</strong> <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <section class="card card-fluid">
                            <header class="card-header">
                                <ul class="nav nav-tabs card-header-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(request()->query("status") ? "" : "active"); ?>"
                                           href="<?php echo e(route("purchases.index")); ?>"
                                        >
                                            All
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(request()->query("status") === "processed" ? "active" : ""); ?>"
                                           href="<?php echo e(route("purchases.index", ["status" => "processed"])); ?>"
                                        >
                                            Processed
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(request()->query("status") === "unprocessed" ? "active" : ""); ?>"
                                           href="<?php echo e(route("purchases.index", ["status" => "unprocessed"])); ?>"
                                        >
                                            Unprocessed
                                        </a>
                                    </li>
                                    <li class="nav-item ">
                                        <a class="nav-link <?php echo e(request()->query("status") === "rejected" ? "active" : ""); ?>"
                                           href="<?php echo e(route("purchases.index", ["status" => "rejected"])); ?>">
                                            Rejected
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(request()->query("status") === "completed" ? "active" : ""); ?>"
                                           href="<?php echo e(route("purchases.index", ["status" => "completed"])); ?>">
                                            Completed
                                        </a>
                                    </li>
                                </ul>
                            </header>

                            <div class="card-body">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <span class="oi oi-magnifying-glass"></span>
                                        </span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Search record">
                                    </div>
                                </div>

                                <!-- .table-responsive -->
                                <div class="text-muted"> Showing 1 to 10 of 1,000 entries </div>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th class="text-left"  nowrap>Number</th>
                                            <th class="text-left"  nowrap>Max</th>
                                            <th class="text-left"  nowrap>Status</th>
                                            <th class="text-left"  nowrap>Members</th>
                                            <th class="text-left"  nowrap>Purchases</th>
                                            <th class="text-left"  nowrap>Harvests</th>
                                            <th nowrap="">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $clusters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cluster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td nowrap>
                                                    <a href="<?php echo e(route("batches.show", $cluster)); ?>" class="user-avatar mr-1">
                                                        <img class="img-fluid"
                                                             src="<?php echo e(Avatar::create($cluster->number)->toBase64()); ?>"
                                                             alt="<?php echo e($cluster->number); ?>"
                                                        >
                                                    </a>
                                                    <a href="<?php echo e(route("batches.show", $cluster)); ?>">
                                                        <?php echo e($cluster->number); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($cluster->max_count); ?></td>
                                                <td><?php echo e($cluster->status); ?></td>
                                                <td>
                                                    <?php echo $__env->make("clusters._member_modal", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                </td>
                                                <td>
                                                    <?php echo $__env->make("clusters._purchases_modal", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                </td>
                                                <td><?php echo e($cluster->harvests->count()); ?></td>
                                                <td nowrap="">
                                                    <?php if($cluster->max_count > $cluster->farmers->count()): ?>
                                                        <?php if(\App\Farmer::query()->whereNotIn("id", $cluster->farmers->pluck("id"))->exists()): ?>
                                                            <?php echo $__env->make("clusters._farmers_modal", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <button type="button" class="btn btn-sm btn-primary">
                                                            Batch is full
                                                        </button>
                                                    <?php endif; ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- .pagination -->
                                <?php echo e($clusters->links()); ?>

                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="wrapper">
            <!-- .empty-state -->
            <section id="notfound-state" class="empty-state">
                <!-- .empty-state-container -->
                <div class="empty-state-container">
                    <div class="state-figure">
                        <img class="img-fluid"
                             src="<?php echo e(asset("themes/looper/assets/images/illustration/img-7.png")); ?>"
                             alt=""
                             style="max-width: 300px">
                    </div>
                    <h3 class="state-header"> No Content, Yet. </h3>
                    <p class="state-description lead text-muted"> Use the button below to add your awesomething, aperiam ex veniam suscipit porro ab saepe nobis odio. </p>
                    <div class="state-action">
                        <a href="<?php echo e(route("farmers.create")); ?>" class="btn btn-primary">Record new a purchase</a>
                    </div>
                </div>
                <!-- /.empty-state-container -->
            </section>
            <!-- /.empty-state -->
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>