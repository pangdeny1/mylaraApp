<?php if(! $purchase->hasAnyStatus(["completed", "rejected"]) ): ?>
<a href="javascript:void(0)"
   class="dropdown-item"
   onclick="event.preventDefault(); document.getElementById('rejectionForm<?php echo e($purchase->id); ?>').submit();"
>
    <i class="far fa-times-circle"></i> Reject
    <form id="rejectionForm<?php echo e($purchase->id); ?>"
          action="<?php echo e(route('purchases.rejections.delete', $purchase)); ?>"
          method="POST"
          class="d-none"
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field("delete"); ?>
    </form>
</a>
<?php endif; ?>