<nav class="page-navs">
    <!-- .nav-scroller -->
    <div class="nav-scroller">
        <!-- .nav -->
        <div class="nav nav-center nav-tabs">
            <a class="nav-link" href="<?php echo e(route("farmers.show", $farmer)); ?>">
                Overview
            </a>
            <a class="nav-link" href="<?php echo e(route("farmers.farms.index", $farmer)); ?>">
                Blocks
                <span class="badge"><?php echo e($farmer->farms->count()); ?></span>
            </a>
            <a class="nav-link" href="<?php echo e(route("farmers.blocks.index", $farmer)); ?>">
                Household Blocks
                <span class="badge"><?php echo e($farmer->householdBlocks->count()); ?></span>
            </a>
            <a class="nav-link" href="<?php echo e(route("farmers.sales.index", $farmer)); ?>">
                Sales
                <span class="badge"><?php echo e($farmer->sales->count()); ?></span>
            </a>
            <a class="nav-link" href="<?php echo e(route("farmers.batches.index", $farmer)); ?>">
                Batches
                <span class="badge"><?php echo e($farmer->batches->count()); ?></span>
            </a>
            <a class="nav-link" href="<?php echo e(route("farmers.harvests.index", $farmer)); ?>">
                Harvests
                <span class="badge"><?php echo e($farmer->harvests->count()); ?></span>
            </a>
            <a class="nav-link" href="<?php echo e(route("farmers.settings.index", $farmer)); ?>">
                Settings
            </a>
        </div>
        <!-- /.nav -->
    </div>
</nav>