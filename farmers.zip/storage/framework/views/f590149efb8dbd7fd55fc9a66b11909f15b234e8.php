<?php $__env->startSection("content"); ?>
    <div class="wrapper">
        <div class="page has-sidebar">
            <div class="sidebar-backdrop"></div>
            <!-- .page-inner -->
            <div class="page-inner">
                <!-- .page-title-bar -->
                <header class="page-title-bar">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active">
                                <a href="#">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i>Settings</a>
                            </li>
                        </ol>
                    </nav>
                    <h1 class="page-title">Change Password</h1>
                </header>

                <!-- .page-section -->
                <div class="page-section">
                    <div class="section-block">
                        <div class="d-xl-none">
                            <button class="btn btn-danger btn-floated" type="button" data-toggle="sidebar">
                                <i class="fa fa-th-list"></i>
                            </button>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <form action="<?php echo e(route("changepassword.update",$user)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="card border-0">
                                        <header class="card-header border-bottom-0">
                                            Change password
                                            <?php if(session('success')): ?>
<div class="alert alert-success" id="id">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>
        <?php if(session('danger')): ?>
            <div class="alert alert-danger" id="id">
                <?php echo e(session('danger')); ?>

            </div>
        <?php endif; ?>
                                        </header>
                                        <div class="card-body">
                                            <div class="form-row">
                                                <div class="form-group col-md-8">
                                                    <label for="old_password">old_password</label>
                                                    <input type="password"
                                                           name="old_password"
                                                           id="old_password"
                                                           class="form-control  <?php echo e($errors->has('old_password') ? "is-invalid" : ""); ?>"
                                                           
                                                           placeholder="old password"
                                                    >
                                                    <?php if($errors->has('old_password')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('old_password')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>

                                            </div>
                                           
                                             <div class="form-row">
                                                <div class="form-group col-md-8">
                                                    <label for="new_password">new_password</label>
                                                    <input type="password"
                                                           name="new_password"
                                                           id="new_password"
                                                           class="form-control  <?php echo e($errors->has('new_password') ? "is-invalid" : ""); ?>"
                                                           
                                                           placeholder="new password"
                                                    >
                                                    <?php if($errors->has('new_password')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('new_password')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                                 <div class="form-row">
                                                <div class="form-group col-md-8">
                                                    <label for="confirm_password">confirm_password</label>
                                                    <input type="password"
                                                           name="confirm_password"
                                                           id="confirm_password"
                                                           class="form-control  <?php echo e($errors->has('confirm_password') ? "is-invalid" : ""); ?>"
                                                           
                                                           placeholder="Confirm password"
                                                    >
                                                    <?php if($errors->has('confirm_password')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('confirm_password')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>

                                            </div>

                                            </div>
                                            <button type="submit" class="btn btn-primary btn-lg btn-block">
                                                Change Password
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- .page-sidebar -->
            <div class="page-sidebar border-left bg-white">
                <header class="sidebar-header d-sm-none">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active">
                                <a href="#" onclick="Looper.toggleSidebar()">
                                    <i class="breadcrumb-icon fa fa-angle-left mr-2"></i>Back</a>
                            </li>
                        </ol>
                    </nav>
                </header>
                <div class="sidebar-section">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>