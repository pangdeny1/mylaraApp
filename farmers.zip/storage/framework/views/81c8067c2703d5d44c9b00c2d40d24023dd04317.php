<!-- Button trigger modal -->
<button type="button"
        class="btn btn-sm btn-secondary"
        data-toggle="modal"
        data-target="#farmersModal<?php echo e($cluster->id); ?>"
>
    Add a member
</button>

<!-- Farmers Modal -->
<div class="modal fade"
     id="farmersModal<?php echo e($cluster->id); ?>"
     tabindex="-1"
     role="dialog"
     aria-labelledby="farmersModalLabel<?php echo e($cluster->id); ?>"
     aria-hidden="true"
>
    <div class="modal-dialog modal-dialog-overflow" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title"> Farmers </h6>
            </div>

            <div class="modal-body px-0">
                <?php $__currentLoopData = \App\Farmer::query()->whereNotIn("id", $cluster->farmers->pluck("id"))->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group list-group-flush list-group-divider border">
                        <div class="list-group-item">
                            <!-- .list-group-item-figure -->
                            <div class="list-group-item-figure">
                                <a href="#" class="user-avatar">
                                    <img src="<?php echo e(Avatar::create($farmer->full_name)->toBase64()); ?>"
                                         alt="<?php echo e($farmer->full_name); ?>"
                                    />
                                </a>
                            </div>

                            <div class="list-group-item-body">
                                <h4 class="list-group-item-title">
                                    <a href="#"><?php echo e($farmer->full_name); ?></a>
                                </h4>
                                <p class="list-group-item-text"> <?php echo e($farmer->phone); ?> </p>
                            </div>

                            <div class="list-group-item-figure">
                                <?php if($cluster->max_count >= $cluster->farmers->count()): ?>
                                <form action="<?php echo e(route("clusters.members.store", $cluster)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="farmer_id" value="<?php echo e($farmer->id); ?>">
                                    <button type="submit" class="btn btn-sm btn-primary">Add</button>
                                </form>
                                <?php else: ?>
                                <button type="submit" class="btn btn-sm btn-secondary">
                                    Batch is full
                                </button>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>