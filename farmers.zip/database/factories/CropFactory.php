<?php

use Faker\Generator as Faker;

$factory->define(App\Crop::class, function (Faker $faker) {
    return [
        //
    ];
});
