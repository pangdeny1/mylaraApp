<a href="javascript:void(0)"
   class="dropdown-item"
>
    <i class="far fa-comment"></i> Remark
</a>