<a href="javascript:void(0)"
   class="dropdown-item"
   onclick="event.preventDefault(); document.getElementById('deletion-form-<?php echo e($purchase->id); ?>').submit();"
>
    <i class="far fa-trash-alt"></i> Delete
    <form id="deletion-form-<?php echo e($purchase->id); ?>"
          action="<?php echo e(route('purchases.destroy', $purchase)); ?>"
          method="POST"
          class="d-none"
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field("delete"); ?>
    </form>
</a>