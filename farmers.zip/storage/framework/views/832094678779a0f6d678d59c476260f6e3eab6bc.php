<?php $__env->startSection("content"); ?>
<div class="wrapper">
    <div class="page has-sidebar">
        <div class="page-inner">
            <header class="page-title-bar">
                <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">
                    <a href="#">
                        <i class="breadcrumb-icon fa fa-angle-left mr-2"></i>Farmers</a>
                    </li>
                </ol>
                </nav>
                <h1 class="page-title"> Farmer registration </h1>
            </header>
            <div class="page-section">
                <div class="row">
                    <div class="col-md-12">

                        <form action="<?php echo e(route("farmers.store")); ?>"
                              method="post"
                              class="card border-0"
                        >
                            <?php echo csrf_field(); ?>
                            <header class="card-header border-bottom-0">
                                Basic information
                            </header>
                            <div class="card-body">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="first_name">First name</label>
                                        <input type="text"
                                               name="first_name"
                                               id="first_name"
                                               class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>"
                                               value="<?php echo e(old("first_name")); ?>"
                                               placeholder="First name..."
                                        >
                                        <?php if($errors->has('first_name')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('first_name')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="last_name">Last name</label>
                                        <input type="text"
                                               name="last_name"
                                               id="last_name"
                                               class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>"
                                               value="<?php echo e(old("last_name")); ?>"
                                               placeholder="Last name..."
                                        >
                                        <?php if($errors->has('last_name')): ?>
                                            <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('last_name')); ?></strong>
                                                </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="phone">Phone number</label>
                                        <input type="text"
                                               name="phone"
                                               id="phone"
                                               class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>"
                                               value="<?php echo e(old("phone")); ?>"
                                               placeholder="Phone number..."
                                        >
                                        <?php if($errors->has('phone')): ?>
                                            <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('phone')); ?></strong>
                                                </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="email">
                                            Email address
                                            <span class="badge badge-secondary">
                                                <em>Optional</em>
                                            </span>
                                        </label>
                                        <input type="email"
                                               name="email"
                                               class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>"
                                               id="email"
                                               placeholder="you@example.com"
                                               value="<?php echo e(old("email")); ?>"
                                        >
                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label class="d-block">Gender identity</label>
                                        <div class="custom-control custom-control-inline custom-radio">
                                            <input type="radio"
                                                   class="custom-control-input"
                                                   name="gender"
                                                   id="female"
                                                   value="female"
                                                   <?php echo e(old("gender") == "female" ? "checked" : ""); ?>

                                            >
                                            <label class="custom-control-label" for="female">Female</label>
                                        </div>
                                        <div class="custom-control custom-control-inline custom-radio">
                                            <input type="radio"
                                                   class="custom-control-input"
                                                   name="gender"
                                                   id="male"
                                                   value="male"
                                                    <?php echo e(old("gender") == "male" ? "checked" : ""); ?>

                                            >
                                            <label class="custom-control-label" for="male">Male</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <header class="card-header border-bottom-0">
                                Group information
                            </header>
                            <div class="card-body">
                                <div class="form-row">
                                    <div class="form-group col-md-12 mb-3">
                                        <label for="group_id">Group name</label>
                                        <select name="group_id"
                                                class="form-control d-block w-100 <?php echo e($errors->has('group_id') ? 'is-invalid' : ''); ?>"
                                                id="group_id"
                                                required=""
                                        >
                                            <option value=""> Choose... </option>
                                            <?php $__currentLoopData = \App\Group::has("products")->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($group->id); ?>" <?php echo e(old("group_id") === $group->id ? "selected" : ""); ?>>
                                                    <?php echo e($group->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback"> Please provide a valid state. </div>
                                    </div>
                                </div>
                            </div>
                            <hr class="mb-4">
                            <header class="card-header border-bottom-0">
                                Address information
                            </header>
                            <div class="card-body">
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="street">Street address</label>
                                        <input type="text"
                                               name="street"
                                               class="form-control <?php echo e($errors->has('street') ? 'is-invalid' : ''); ?>"
                                               id="street"
                                               value="<?php echo e(old("street")); ?>"
                                               placeholder="1234 Main St"
                                        >
                                        <?php if($errors->has('street')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('street')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="address">
                                            Address 2
                                            <span class="badge badge-secondary">
                                                    <em>Optional</em>
                                                </span>
                                        </label>
                                        <input type="text"
                                               name="address"
                                               class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>"
                                               id="address"
                                               placeholder="Apartment or suite"
                                        >
                                        <?php if($errors->has('address')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('address')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col-md-5 mb-3">
                                        <label for="country">Country</label>
                                        <select name="country"
                                                class="custom-select d-block w-100"
                                                id="country"
                                        >
                                            <option value="Tanzania">Tanzania</option>
                                        </select>
                                        <div class="invalid-feedback"> Please select a valid country. </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="state">State</label>
                                        <select name="state"
                                                class="form-control d-block w-100 <?php echo e($errors->has('state') ? 'is-invalid' : ''); ?>"
                                                id="state"
                                                required=""
                                        >
                                            <option value=""> Choose... </option>
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option name="<?php echo e($state["name"]); ?>" <?php echo e(old("state") === $state["name"] ? "selected" : ""); ?>>
                                                    <?php echo e($state["name"]); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback"> Please provide a valid state. </div>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="postal_code">Zip</label>
                                        <input type="text"
                                               name="postal_code"
                                               class="form-control <?php echo e($errors->has('postal_code') ? 'is-invalid' : ''); ?>"
                                               id="postal_code"
                                               value="<?php echo e(old("postal_code")); ?>"
                                        >
                                        <?php if($errors->has('postal_code')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('postal_code')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <hr class="mb-4">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">
                                    Save changes
                                </button>
                            </div>
                      </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-sidebar border-left bg-white">
            <header class="sidebar-header d-sm-none">
                <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">
                    <a href="#" onclick="Looper.toggleSidebar()">
                        <i class="breadcrumb-icon fa fa-angle-left mr-2"></i>Back</a>
                    </li>
                </ol>
                </nav>
            </header>
            <div class="sidebar-section">
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>