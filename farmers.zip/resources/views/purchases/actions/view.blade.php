<a href="{{ route("purchases.show", $purchase) }}" class="dropdown-item">
    <i class="far fa-file"></i> View
</a>