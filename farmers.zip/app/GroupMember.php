<?php

namespace App;

use Illuminate\Database\Eloquent\Relations\Pivot;

class GroupMember extends Pivot {}
